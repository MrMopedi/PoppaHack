import sys,os
from colorama import Fore

print(Fore.BLUE+"""

 ██▓███   ▒█████   ██▓███   ██▓███   ▄▄▄         ▄▄▄█████▓ ▒█████   ▒█████   ██▓    
▓██░  ██▒▒██▒  ██▒▓██░  ██▒▓██░  ██▒▒████▄       ▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    
▓██░ ██▓▒▒██░  ██▒▓██░ ██▓▒▓██░ ██▓▒▒██  ▀█▄     ▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    
▒██▄█▓▒ ▒▒██   ██░▒██▄█▓▒ ▒▒██▄█▓▒ ▒░██▄▄▄▄██    ░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    
▒██▒ ░  ░░ ████▓▒░▒██▒ ░  ░▒██▒ ░  ░ ▓█   ▓██▒     ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒
▒▓▒░ ░  ░░ ▒░▒░▒░ ▒▓▒░ ░  ░▒▓▒░ ░  ░ ▒▒   ▓▒█░     ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░
░▒ ░       ░ ▒ ▒░ ░▒ ░     ░▒ ░       ▒   ▒▒ ░       ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░
░░       ░ ░ ░ ▒  ░░       ░░         ░   ▒        ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   
             ░ ░                          ░  ░                ░ ░      ░ ░      ░  ░
      """)
print(Fore.RED+"""                                                                                                                                                 
BY : 𝕻𝖔𝖕𝖕𝖆𝕸𝖎𝖊𝖘
""")

def display_menu():
    print(Fore.YELLOW + """
    ―――――――――――――――――――――――――――――――――――――――――――――――――――――――
    1. Ip-Scanner                   | 7. Sub-Domain-Scanner      
    2. Discord-Nuke                 | 8. DDOS-TOOL
    3. Subdirectory-Scanner         | 9. Discord-Token-Grabber
    4. Email-Boomber                | 10. Keylogger 
    5. Phone-Locator                | 11. Web-Crawler
    6. Port-Scanner                 | 12. Reverse-Shell 
    ――――――――――――――――――――――――――――――――――――――――――――――――――――――――
    """)

def execute_command(command):
    if command == '1':
        os.system('cmd /k "python PoppaTool/ip-lookup.py"' if os.name == 'nt' else 'python PoppaTool/ip-lookup.py')
    elif command == '2':
        os.system('cmd /k "python PoppaTool/nuke-bot/main.py"' if os.name == 'nt' else 'python PoppaTool/nuke-bot/main.py')
    elif command == '3':
        os.system('cmd /k "python PoppaTool/Subdirectory-scanner/main.py"' if os.name == 'nt' else 'python PoppaTool/Subdirectory-scanner/main.py')
    elif command == '4':
        os.system('cmd /k "python PoppaTool/email-bomber.py"' if os.name == 'nt' else 'python PoppaTool/email-bomber.py')
    elif command == '5':
        os.system('cmd /k "python PoppaTool/phone-locator.py"' if os.name == 'nt' else 'python PoppaTool/phone-locator.py')
    elif command == '6':
        os.system('cmd /k "python PoppaTool/port-scanner.py"' if os.name == 'nt' else 'python PoppaTool/port-scanner.py"')
    elif command == '7':
        os.system('cmd /k "python PoppaTool/subdomain/main.py"' if os.name == 'nt' else 'python PoppaTool/subdomain/main.py')
    elif command == '8':
        os.system('cmd /k "python PoppaTool/ddos.py"' if os.name == 'nt' else 'python PoppaTool/ddos.py')
    elif command == '9':
        os.system('cmd /k "python PoppaTool/discord-token-grabber.py"' if os.name == 'nt' else 'python PoppaTool/discord-token-grabber.py')
    elif command == '10':
        print(Fore.RED + 'This option is not available yet! Coming soon...')
        #os.system('cmd /k "python PoppaTool/Keylogger.py"')
    elif command == '11':
        print(Fore.RED + 'This option is not available yet! Coming soon...')
        #os.system('cmd /k "python PoppaTool/Web-Crawler.py"')
    elif command == '12':
        print(Fore.RED + 'This option is not available yet! Coming soon...')
        #os.system('cmd /k "python PoppaTool/Reverse-Shell.py"')
    else:
        print(Fore.RED + 'Invalid option! Please choose the correct one.')

while True:
    display_menu()
    command = input('> ')

    if command.lower() == 'exit':
        break

    execute_command(command)
