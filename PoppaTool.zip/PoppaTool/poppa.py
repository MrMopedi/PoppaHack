import sys,os
from colorama import Fore

print(Fore.BLUE+"""

 ██▓███   ▒█████   ██▓███   ██▓███   ▄▄▄         ▄▄▄█████▓ ▒█████   ▒█████   ██▓    
▓██░  ██▒▒██▒  ██▒▓██░  ██▒▓██░  ██▒▒████▄       ▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    
▓██░ ██▓▒▒██░  ██▒▓██░ ██▓▒▓██░ ██▓▒▒██  ▀█▄     ▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    
▒██▄█▓▒ ▒▒██   ██░▒██▄█▓▒ ▒▒██▄█▓▒ ▒░██▄▄▄▄██    ░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    
▒██▒ ░  ░░ ████▓▒░▒██▒ ░  ░▒██▒ ░  ░ ▓█   ▓██▒     ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒
▒▓▒░ ░  ░░ ▒░▒░▒░ ▒▓▒░ ░  ░▒▓▒░ ░  ░ ▒▒   ▓▒█░     ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░
░▒ ░       ░ ▒ ▒░ ░▒ ░     ░▒ ░       ▒   ▒▒ ░       ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░
░░       ░ ░ ░ ▒  ░░       ░░         ░   ▒        ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   
             ░ ░                          ░  ░                ░ ░      ░ ░      ░  ░
      """)
print(Fore.RED+"""                                                                                                                                                 
BY: PoppaMies
""")

def display_menu():
    print(Fore.GREEN + """
    1: PoppaTool      | 2:IDK
    """)

def execute_command(command):
    if command == '1':
        os.system('cmd /k "python PoppaTool/poppatool.py"' if os.name == 'nt' else 'python PoppaTool/poppatool.py')
    elif command == '2':
        print(Fore.RED + 'This option is not available yet! Coming soon...')
    elif command == '3':
        print(Fore.RED + 'This option is not available! Only use 1-2!!')

        display_menu()
    else:
        print('Invalid option! Please choose the correct one.')

while True:
    display_menu()
    command = input('> ')

    if command.lower() == 'exit':
        break

    execute_command(command)
