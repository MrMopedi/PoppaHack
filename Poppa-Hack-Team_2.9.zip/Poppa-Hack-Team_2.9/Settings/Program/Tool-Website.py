from Config.Util import *
from Config.Config import *
try:
    import webbrowser
except Exception as e:
   ErrorModule(e)

Title("Tool Website")
print(f"""
{color.RED}[!]{color.GREEN} -> We dont have one yet""")
Continue()
Reset()