1. When starting please open setup.bat or setup.py

2. Stealer Builder doesnt work it will probaly work in 3.0

3. DONT change the scripts it WILL break the tool!